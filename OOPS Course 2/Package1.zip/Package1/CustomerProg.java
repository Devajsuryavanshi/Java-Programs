package Package1;
import java.util.*;

public class CustomerProg {
    
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);
        Customer anuj = new Customer();

        System.out.println("Enter Customer details ");
        System.out.println("id ");
        anuj.setId(sc.nextLong());
        System.out.println("Name ");
        anuj.setName(sc.next());
        System.out.println("Gender");
        anuj.setGender(sc.next().charAt(0));
        System.out.println("Email ");
        anuj.setEmail(sc.next());
        System.out.println("Contact number -");
        anuj.setContactNumber(sc.next());

        System.out.println("id -" +anuj.getId());
        System.out.println(anuj.toString(anuj));

        sc.close();
    }
}

class Customer{

    private long id;
    private String name;
    private char gender;
    private String email;
    private String contactNumber;


    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public char getGender() {
        return gender;
    }
    public void setGender(char gender) {
        this.gender = gender;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getContactNumber() {
        return contactNumber;
    }
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String toString(Customer obj){
        System.out.println("Customer: " +obj.getName());
        return "Customer contact details :" +obj.getContactNumber()+", "+obj.getEmail();
    }
}